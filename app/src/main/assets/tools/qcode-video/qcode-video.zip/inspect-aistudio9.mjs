import http from 'node:http';
const CDP_HTTP = process.env.QCODE_CDP || 'http://127.0.0.1:9222';
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
function getJson(url){return new Promise((res,rej)=>{const q=http.get(url,r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>{try{res(JSON.parse(d));}catch(e){rej(e);}});});q.on('error',rej);q.setTimeout(5000,()=>q.destroy(new Error('timeout')));});}
class Cdp{constructor(u){this.ws=new WebSocket(u);this.id=0;this.p=new Map();this.ready=new Promise((r,j)=>{this.ws.onopen=r;this.ws.onerror=()=>j(new Error('ws'));});this.ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&this.p.has(m.id)){const x=this.p.get(m.id);this.p.delete(m.id);m.error?x.j(new Error(m.error.message)):x.r(m.result);}};}async send(m,a={}){await this.ready;return new Promise((r,j)=>{const id=++this.id;const t=setTimeout(()=>{this.p.delete(id);j(new Error(m+' timeout'));},30000);this.p.set(id,{r:v=>{clearTimeout(t);r(v);},j:e=>{clearTimeout(t);j(e);}});this.ws.send(JSON.stringify({id,method:m,params:a}));});}async eval(e){const r=await this.send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.text);return r.result?.value;}close(){try{this.ws.close();}catch{}}}
const targets=await getJson(`${CDP_HTTP}/json`);const page=targets.find(t=>t.type==='page');const cdp=new Cdp(page.webSocketDebuggerUrl);
try{
 await cdp.send('Runtime.enable');
 console.log('OPEN VOICE:', await cdp.eval(`(() => { const b=[...document.querySelectorAll('button')].find(x=>(x.innerText||'').includes('Speaker 1')); if(!b) return 'missing'; b.click(); return 'clicked'; })()`));
 await sleep(1200);
 console.log('OPEN LANG:', await cdp.eval(`(() => { const b=[...document.querySelectorAll('button')].find(x=>/^Language/.test((x.innerText||'').trim())); if(!b) return 'missing'; b.click(); return 'clicked'; })()`));
 await sleep(1200);
 console.log('BODY:\n'+(await cdp.eval('document.body.innerText.slice(0,5000)')));
 const expr = `JSON.stringify([...document.querySelectorAll('[role="option"],mat-option,[role="menuitem"],button')].map(e=>({tag:e.tagName,role:e.getAttribute('role'),text:(e.innerText||'').trim().slice(0,80),aria:e.getAttribute('aria-label')})).filter(x=>/Odia|Oriya|Language|Hindi|English|All/i.test(x.text||'')||/Odia|Oriya|Language/i.test(x.aria||'')),null,1)`;
 console.log('OPTIONS:\n'+(await cdp.eval(expr)));
}finally{cdp.close();}
