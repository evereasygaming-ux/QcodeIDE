import http from 'node:http';

const CDP_HTTP = process.env.QCODE_CDP || 'http://127.0.0.1:9222';
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function getJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, res => {
      let data = '';
      res.on('data', c => { data += c; });
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(5000, () => req.destroy(new Error('CDP HTTP timeout')));
  });
}
class Cdp {
  constructor(wsUrl) {
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
    this.ready = new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = () => reject(new Error('CDP WebSocket failed'));
    });
    this.ws.onmessage = ev => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const p = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error.message || 'CDP error'));
        else p.resolve(msg.result);
      }
    };
  }
  async send(method, params = {}) {
    await this.ready;
    return new Promise((resolve, reject) => {
      const id = ++this.id;
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`CDP ${method} timed out`)); }, 30000);
      this.pending.set(id, { resolve: v => { clearTimeout(timer); resolve(v); }, reject: e => { clearTimeout(timer); reject(e); } });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression) {
    const r = await this.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text || 'Page script failed');
    return r.result?.value;
  }
  close() { try { this.ws.close(); } catch {} }
}

const targets = await getJson(`${CDP_HTTP}/json`);
const page = targets.find(t => t.type === 'page');
if (!page) throw new Error('No page target');
const cdp = new Cdp(page.webSocketDebuggerUrl);
try {
  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Page.navigate', { url: 'https://aistudio.google.com/generate-speech' });
  await sleep(10000);
  console.log('URL:', await cdp.eval('location.href'));
  console.log('TITLE:', await cdp.eval('document.title'));
  console.log('BODY:\n' + (await cdp.eval('document.body.innerText.slice(0, 5000)')));
  console.log('BUTTONS:\n' + (await cdp.eval(`JSON.stringify([...document.querySelectorAll('button')].map(b => ({t:(b.innerText||'').trim().slice(0,80), a:b.getAttribute('aria-label'), d:b.disabled})).filter(x=>x.t||x.a), null, 1)`)));
  console.log('TEXTAREAS:\n' + (await cdp.eval(`JSON.stringify([...document.querySelectorAll('textarea,[contenteditable="true"],input')].map(e => ({tag:e.tagName, type:e.type, ph:e.placeholder, aria:e.getAttribute('aria-label'), text:(e.innerText||e.value||'').slice(0,100)})), null, 1)`)));
} finally {
  cdp.close();
}
