import http from 'node:http';
const CDP_HTTP = process.env.QCODE_CDP || 'http://127.0.0.1:9222';
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function getJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, res => { let d=''; res.on('data',c=>d+=c); res.on('end',()=>{try{resolve(JSON.parse(d));}catch(e){reject(e);}}); });
    req.on('error', reject); req.setTimeout(5000, () => req.destroy(new Error('timeout')));
  });
}
class Cdp {
  constructor(wsUrl) {
    this.ws = new WebSocket(wsUrl); this.id = 0; this.pending = new Map();
    this.ready = new Promise((res, rej) => { this.ws.onopen = res; this.ws.onerror = () => rej(new Error('ws failed')); });
    this.ws.onmessage = ev => { const m = JSON.parse(ev.data); if (m.id && this.pending.has(m.id)) { const p=this.pending.get(m.id); this.pending.delete(m.id); m.error?p.reject(new Error(m.error.message)):p.resolve(m.result); } };
  }
  async send(method, params={}) { await this.ready; return new Promise((res,rej)=>{ const id=++this.id; const t=setTimeout(()=>{this.pending.delete(id);rej(new Error(method+' timeout'));},30000); this.pending.set(id,{resolve:v=>{clearTimeout(t);res(v);},reject:e=>{clearTimeout(t);rej(e);}}); this.ws.send(JSON.stringify({id,method,params})); }); }
  async eval(expression) { const r = await this.send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true}); if (r.exceptionDetails) throw new Error(r.exceptionDetails.text); return r.result?.value; }
  close(){try{this.ws.close();}catch{}}
}
const targets = await getJson(`${CDP_HTTP}/json`);
const page = targets.find(t => t.type === 'page');
const cdp = new Cdp(page.webSocketDebuggerUrl);
try {
  await cdp.send('Page.enable'); await cdp.send('Runtime.enable');
  await cdp.send('Page.navigate', { url: 'https://aistudio.google.com/generate-speech' });
  await sleep(8000);
  console.log('CLICK:', await cdp.eval(`(() => { const b=[...document.querySelectorAll('button')].find(x=>(x.innerText||'').includes('Create new dialog')); if(!b) return false; b.click(); return true; })()`));
  await sleep(6000);
  console.log('URL:', await cdp.eval('location.href'));
  console.log('BODY:\n' + (await cdp.eval('document.body.innerText.slice(0, 4000)')));
  console.log('EDITABLES:\n' + (await cdp.eval(`JSON.stringify([...document.querySelectorAll('[contenteditable="true"],textarea,input,[role="textbox"]')].map(e=>({tag:e.tagName,role:e.getAttribute('role'),aria:e.getAttribute('aria-label'),ph:e.placeholder,text:(e.innerText||e.value||'').slice(0,120)})),null,1)`)));
  console.log('BUTTONS:\n' + (await cdp.eval(`JSON.stringify([...document.querySelectorAll('button')].map(b=>({t:(b.innerText||'').trim().slice(0,100),a:b.getAttribute('aria-label'),d:b.disabled})).filter(x=>x.t||x.a),null,1)`)));
} finally { cdp.close(); }
