#!/bin/sh
set -e
cd /workspace/.qcode-tools/video
node qcode-video.mjs --spec /workspace/.qcode-tools/video/hindi-spec.json --out /workspace/qcodesmoke/qcode-videos/tara-hindi-demo.mp4
