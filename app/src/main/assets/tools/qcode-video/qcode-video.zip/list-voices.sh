#!/bin/sh
cd /workspace/.qcode-tools/video
node qcode-video.mjs --list-voices > /workspace/qcodesmoke/qcode-videos/voices.tsv
