#!/bin/sh
set -e
cd /workspace/.qcode-tools/video
node qcode-video.mjs --spec /workspace/.qcode-tools/video/tutorial-spec.json --out /workspace/qcodesmoke/qcode-videos/qcode-ide-beginner-tutorial.mp4
