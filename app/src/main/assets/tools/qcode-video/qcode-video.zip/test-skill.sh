#!/bin/sh
cd /workspace/qcodesmoke
export HOME=/home/jcode
export PATH=/root/.local/bin:$PATH
timeout 180 /root/.local/bin/agy --output-format json --dangerously-skip-permissions --print="List the exact names of all skills available to you. Do not call any tools. Answer in one line." 2>&1 | tail -30
