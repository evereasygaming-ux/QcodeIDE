#!/bin/sh
set -e
cd /workspace/.qcode-tools/video
node qcode-video.mjs --prompt 'a cute cartoon star in a night sky, children storybook illustration' --language hi --out /workspace/qcodesmoke/qcode-videos/test-hi.mp4
