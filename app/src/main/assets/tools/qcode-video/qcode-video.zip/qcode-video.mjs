#!/usr/bin/env node
/**
 * QCODE Video Studio
 * Prompt/spec -> generated images -> multilingual voiceover -> MP4.
 *
 * The agent writes a JSON spec (it does the creative planning), then this tool
 * generates images, speech, and the final video. Everything runs on-device.
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { spawn } from 'node:child_process';
import { MsEdgeTTS, OUTPUT_FORMAT } from 'msedge-tts';
import ffmpegStatic from 'ffmpeg-static';
import { generateFlowImage } from './flow-cdp.mjs';

const FFMPEG = process.env.QCODE_FFMPEG || ffmpegStatic;
const DEFAULT_WIDTH = 720;
const DEFAULT_HEIGHT = 1280;
const DEFAULT_FPS = 30;
const TTS_FORMAT = OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3;
const LANG_NAMES = { en: 'English', hi: 'Hindi', or: 'Odia' };

function loadEnv() {
  const files = [path.join(import.meta.dirname, '.env'), path.join(process.cwd(), '.env')];
  for (const file of files) {
    try {
      for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
        const line = raw.trim();
        if (!line || line.startsWith('#')) continue;
        const m = line.match(/^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
        if (!m) continue;
        let value = m[2].trim();
        if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
          value = value.slice(1, -1);
        }
        if (process.env[m[1]] === undefined) process.env[m[1]] = value;
      }
    } catch { /* no .env */ }
  }
}

const VOICES = {
  en: 'en-US-AriaNeural', hi: 'hi-IN-SwaraNeural', ur: 'ur-PK-UzmaNeural',
  bn: 'bn-IN-TanishaaNeural', ta: 'ta-IN-PallaviNeural', te: 'te-IN-ShrutiNeural',
  mr: 'mr-IN-AarohiNeural', gu: 'gu-IN-DhwaniNeural', kn: 'kn-IN-SapnaNeural',
  ml: 'ml-IN-SobhanaNeural', pa: 'pa-IN-GurpreetNeural', or: 'or-IN-SubhasiniNeural',
  as: 'as-IN-YashicaNeural', ne: 'ne-NP-HemkalaNeural', si: 'si-LK-ThiliniNeural',
  zh: 'zh-CN-XiaoxiaoNeural', 'zh-cn': 'zh-CN-XiaoxiaoNeural', 'zh-tw': 'zh-TW-HsiaoChenNeural',
  ja: 'ja-JP-NanamiNeural', ko: 'ko-KR-SunHiNeural', ru: 'ru-RU-SvetlanaNeural',
  uk: 'uk-UA-PolinaNeural', pl: 'pl-PL-ZofiaNeural', cs: 'cs-CZ-VlastaNeural',
  sk: 'sk-SK-ViktoriaNeural', hu: 'hu-HU-NoemiNeural', ro: 'ro-RO-AlinaNeural',
  bg: 'bg-BG-KalinaNeural', sr: 'sr-RS-SophieNeural', hr: 'hr-HR-GabrijelaNeural',
  sl: 'sl-SI-PetraNeural', de: 'de-DE-KatjaNeural', fr: 'fr-FR-DeniseNeural',
  es: 'es-ES-ElviraNeural', pt: 'pt-BR-FranciscaNeural', it: 'it-IT-ElsaNeural',
  nl: 'nl-NL-ColetteNeural', sv: 'sv-SE-SofieNeural', no: 'nb-NO-PernilleNeural',
  nb: 'nb-NO-PernilleNeural', da: 'da-DK-ChristelNeural', fi: 'fi-FI-NooraNeural',
  et: 'et-EE-AnuNeural', lv: 'lv-LV-EveritaNeural', lt: 'lt-LT-OnaNeural',
  tr: 'tr-TR-EmelNeural', ar: 'ar-SA-ZariyahNeural', he: 'he-IL-HilaNeural',
  fa: 'fa-IR-DilaraNeural', sw: 'sw-KE-ZuriNeural', af: 'af-ZA-AdriNeural',
  id: 'id-ID-GadisNeural', ms: 'ms-MY-YasminNeural', th: 'th-TH-PremwadeeNeural',
  vi: 'vi-VN-HoaiMyNeural', fil: 'fil-PH-BlessicaNeural', tl: 'fil-PH-BlessicaNeural',
  el: 'el-GR-AthinaNeural', ca: 'ca-ES-JoanaNeural', eu: 'eu-ES-AinhoaNeural',
  gl: 'gl-ES-SabelaNeural', is: 'is-IS-GudrunNeural', ga: 'ga-IE-OrlaNeural',
  mt: 'mt-MT-GraceNeural', mk: 'mk-MK-MarijaNeural', bs: 'bs-BA-VesnaNeural',
  sq: 'sq-AL-AnilaNeural', hy: 'hy-AM-AnahitNeural', ka: 'ka-GE-EkaNeural',
  az: 'az-AZ-BanuNeural', kk: 'kk-KZ-AigulNeural', uz: 'uz-UZ-MadinaNeural',
  mn: 'mn-MN-YesuiNeural', km: 'km-KH-SreymomNeural', lo: 'lo-LA-KeomanyNeural',
  my: 'my-MM-NilarNeural', ps: 'ps-AF-LatifaNeural', sd: 'sd-PK-SanaNeural',
};

function usage() {
  console.log(`QCODE Video Studio
Usage:
  node qcode-video.mjs --spec spec.json [--out video.mp4] [--work dir] [--keep-work]
  node qcode-video.mjs --spec spec.json --tts-provider gemini|elevenlabs|edge|auto
  node qcode-video.mjs --list-voices [--language hi]
  node qcode-video.mjs --prompt "..." [--language hi] [--out video.mp4]   (simple one-scene test)

Spec:
{
  "title": "The Little Star",
  "language": "hi",
  "voice": "hi-IN-SwaraNeural",
  "ttsProvider": "auto",
  "geminiVoice": "Kore",
  "elevenLabsVoice": "<voice-id>",
  "imageProvider": "flow",
  "flowProject": "https://flow.google.com/project/<id>",
  "width": 720, "height": 1280, "fps": 30,
  "scenes": [
    { "imagePrompt": "storybook illustration...", "narration": "..." },
    { "image": "/workspace/.../scene.png", "narration": "...", "fit": "contain", "seconds": 8 }
  ]
}

Image providers: pollinations (default), flow (DeepX/Google Flow via the QCODE Browser).
Flow needs the host CDP forward active and Google Flow signed in:
  adb forward tcp:9222 localabstract:webview_devtools_remote_<pid>

TTS providers: auto (default), gemini, elevenlabs, edge.
auto order: gemini -> elevenlabs -> edge (edge has no Odia).
Natural Hindi/English/Odia:
  GEMINI_API_KEY=...        Google AI Studio free tier
  ELEVENLABS_API_KEY=...    ElevenLabs free plan, model eleven_v3
Optional: GEMINI_TTS_MODEL, GEMINI_TTS_VOICE, ELEVENLABS_MODEL, ELEVENLABS_VOICE_ID.
Put keys in .env next to this file, or pass --tts-provider.
`);
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--keep-work') out.keepWork = true;
    else if (a === '--list-voices') out.listVoices = true;
    else if (a === '--help' || a === '-h') out.help = true;
    else if (a.startsWith('--')) {
      const key = a.slice(2).replace(/-([a-z])/g, (_, c) => c.toUpperCase());
      out[key] = argv[++i];
    }
    else out._.push(a);
  }
  return out;
}

function slugify(s) {
  const ascii = String(s || '').normalize('NFKD').replace(/[^\x00-\x7F]/g, '');
  return ascii.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48) || 'qcode-video';
}

function xmlEscape(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function whichFfmpeg() {
  if (!FFMPEG) throw new Error('ffmpeg-static is not installed. Run: npm install in the qcode-video folder.');
  return FFMPEG;
}

function run(cmd, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'], ...opts });
    let out = '', err = '';
    p.stdout.on('data', d => { out += d; });
    p.stderr.on('data', d => { err += d; });
    p.on('error', reject);
    p.on('close', code => {
      if (code === 0) resolve({ out, err });
      else reject(new Error(`${path.basename(cmd)} exited ${code}\n${err.slice(-2000)}`));
    });
  });
}

async function isImageFile(file) {
  try {
    const fh = await fsp.open(file, 'r');
    const buf = Buffer.alloc(12);
    await fh.read(buf, 0, 12, 0);
    await fh.close();
    return (buf[0] === 0xff && buf[1] === 0xd8) || buf.slice(0, 8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));
  } catch { return false; }
}

async function fetchImage(prompt, width, height, seed, dest) {
  const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&seed=${seed}&nologo=true&model=flux`;
  let lastErr;
  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      try {
        await run('curl', ['-fL', '--silent', '--show-error', '--max-time', '90', '-o', dest, url]);
      } catch (ce) {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 90000);
        const res = await fetch(url, { signal: ctrl.signal });
        clearTimeout(timer);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        await fsp.writeFile(dest, Buffer.from(await res.arrayBuffer()));
      }
      const st = await fsp.stat(dest);
      if (st.size < 1000 || !(await isImageFile(dest))) throw new Error('not a valid image');
      console.log(`  image ok (${Math.round(st.size / 1024)} KiB)`);
      return dest;
    } catch (e) {
      lastErr = e;
      console.log(`  image attempt ${attempt} failed: ${e.message.split('\n')[0]}`);
      await sleep(3000 * attempt);
    }
  }
  throw lastErr;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function fallbackImage(dest, width, height) {
  await run(whichFfmpeg(), [
    '-hide_banner', '-loglevel', 'error', '-y',
    '-f', 'lavfi', '-i', `color=c=0x1e293b:s=${width}x${height}:d=1`,
    '-frames:v', '1', dest,
  ]);
}

async function synthesizeEdge(voice, text, dir, prosody) {
  const tts = new MsEdgeTTS({ connectionTimeoutMs: 20000, synthesisTimeoutMs: 180000 });
  await tts.setMetadata(voice, TTS_FORMAT);
  fs.mkdirSync(dir, { recursive: true });
  const { audioFilePath } = await tts.toFile(dir, xmlEscape(text), prosody);
  tts.close();
  return audioFilePath;
}

function pcmToWav(pcm, sampleRate = 24000, channels = 1, bits = 16) {
  const header = Buffer.alloc(44);
  const blockAlign = channels * bits / 8;
  header.write('RIFF', 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * blockAlign, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bits, 34);
  header.write('data', 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

async function geminiTts(text, dir, { voice, lang }) {
  const key = process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_STUDIO_API_KEY;
  if (!key) throw new Error('GEMINI_API_KEY is not set');
  const model = process.env.GEMINI_TTS_MODEL || 'gemini-3.8-flash-tts';
  const voiceName = voice || process.env.GEMINI_TTS_VOICE || 'Kore';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const body = {
    contents: [{ parts: [{ text: String(text) }] }],
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName } } },
    },
  };
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const raw = await res.text();
  if (!res.ok) throw new Error(`Gemini TTS HTTP ${res.status}: ${raw.slice(0, 300)}`);
  let json;
  try { json = JSON.parse(raw); } catch { throw new Error(`Gemini TTS: invalid JSON: ${raw.slice(0, 200)}`); }
  const parts = json?.candidates?.[0]?.content?.parts || [];
  const part = parts.find(p => p.inlineData?.data || p.inline_data?.data);
  if (!part) throw new Error(`Gemini TTS: no audio in response (${json?.error?.message || 'empty candidates'})`);
  const inline = part.inlineData || part.inline_data;
  const buf = Buffer.from(inline.data, 'base64');
  const mime = String(inline.mimeType || inline.mime_type || '');
  fs.mkdirSync(dir, { recursive: true });
  const dest = path.join(dir, 'voice.wav');
  if (buf.subarray(0, 4).toString() === 'RIFF' || mime.includes('wav')) {
    await fsp.writeFile(dest, buf);
  } else {
    const rate = Number((mime.match(/rate=(\d+)/) || [])[1]) || 24000;
    await fsp.writeFile(dest, pcmToWav(buf, rate));
  }
  return dest;
}

async function pickElevenLabsVoice(key) {
  try {
    const res = await fetch('https://api.elevenlabs.io/v1/voices', { headers: { 'xi-api-key': key } });
    if (!res.ok) return process.env.ELEVENLABS_VOICE_ID || 'JBFqnCBsd6RMkjVDRZzb';
    const json = await res.json();
    const premade = (json.voices || []).filter(v => v.category === 'premade');
    const preferred = ['Talia', 'George', 'Sarah', 'Rachel'];
    for (const name of preferred) {
      const hit = premade.find(v => v.name === name);
      if (hit) return hit.voice_id;
    }
    if (premade.length) return premade[0].voice_id;
  } catch { /* fall through */ }
  return process.env.ELEVENLABS_VOICE_ID || 'JBFqnCBsd6RMkjVDRZzb';
}

async function elevenLabsTts(text, dir, { voice, lang }) {
  const key = process.env.ELEVENLABS_API_KEY;
  if (!key) throw new Error('ELEVENLABS_API_KEY is not set');
  const voiceId = voice || process.env.ELEVENLABS_VOICE_ID || await pickElevenLabsVoice(key);
  const model = process.env.ELEVENLABS_MODEL || 'eleven_v3';
  const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'xi-api-key': key,
      'content-type': 'application/json',
      accept: 'audio/mpeg',
    },
    body: JSON.stringify({
      text: String(text),
      model_id: model,
      voice_settings: { stability: 0.5, similarity_boost: 0.75, style: 0.0, use_speaker_boost: true },
    }),
  });
  if (!res.ok) {
    const raw = await res.text();
    throw new Error(`ElevenLabs HTTP ${res.status}: ${raw.slice(0, 300)}`);
  }
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 1000) throw new Error('ElevenLabs returned an empty audio file');
  fs.mkdirSync(dir, { recursive: true });
  const dest = path.join(dir, 'voice.mp3');
  await fsp.writeFile(dest, buf);
  return dest;
}

function ttsPriority(lang, requested) {
  const provider = String(requested || process.env.QCODE_TTS_PROVIDER || 'auto').toLowerCase();
  if (provider !== 'auto') return [provider];
  const list = [];
  if (process.env.GEMINI_API_KEY || process.env.GOOGLE_AI_STUDIO_API_KEY) list.push('gemini');
  if (process.env.ELEVENLABS_API_KEY) list.push('elevenlabs');
  list.push('edge');
  return list;
}

async function synthesizeText({ text, dir, lang, provider, voices, prosody }) {
  const errors = [];
  const providers = ttsPriority(lang, provider);
  if (lang === 'or' && providers.every(p => p === 'edge')) {
    throw new Error('Odia is not available on Edge; set GEMINI_API_KEY or ELEVENLABS_API_KEY');
  }
  for (const p of providers) {
    try {
      if (p === 'gemini') return await geminiTts(text, dir, { voice: voices.gemini, lang });
      if (p === 'elevenlabs') return await elevenLabsTts(text, dir, { voice: voices.elevenlabs, lang });
      if (p === 'edge') return await synthesizeEdge(voices.edge, text, dir, prosody);
      throw new Error(`unknown TTS provider "${p}"`);
    } catch (e) {
      errors.push(`${p}: ${e.message.split('\n')[0]}`);
      console.log(`  tts ${p} failed: ${e.message.split('\n')[0]}`);
    }
  }
  throw new Error(`TTS failed for ${lang}: ${errors.join(' | ')}`);
}

async function resolveVoice(spec, requested) {
  if (requested) return requested;
  if (spec.voice) return spec.voice;
  const lang = String(spec.language || 'en').toLowerCase();
  const direct = VOICES[lang] || VOICES[lang.split('-')[0]] || VOICES[String(spec.language || 'en').toLowerCase()];
  if (direct) return direct;
  try {
    const tts = new MsEdgeTTS();
    const voices = await tts.getVoices();
    tts.close();
    const prefix = lang.split('-')[0];
    const matches = voices.filter(v => v.Locale.toLowerCase().startsWith(prefix));
    if (matches.length) {
      const female = matches.find(v => v.Gender === 'Female') || matches[0];
      return female.ShortName;
    }
  } catch { /* fall through */ }
  return 'en-US-AriaNeural';
}

async function listVoices(language) {
  const tts = new MsEdgeTTS();
  const voices = await tts.getVoices();
  tts.close();
  const prefix = language ? String(language).toLowerCase().split('-')[0] : '';
  const rows = voices
    .filter(v => !prefix || v.Locale.toLowerCase().startsWith(prefix))
    .sort((a, b) => a.Locale.localeCompare(b.Locale) || a.ShortName.localeCompare(b.ShortName));
  for (const v of rows) console.log(`${v.ShortName}\t${v.Locale}\t${v.Gender}\t${v.FriendlyName}`);
  if (!rows.length) console.error(`No voices for ${language}`);
}

async function makeSegment({ image, audio, out, width, height, fps, fit, seconds, index }) {
  const ffmpeg = whichFfmpeg();
  const isVideo = /\.(mp4|mov|webm|mkv|m4v)$/i.test(image);
  const args = ['-hide_banner', '-loglevel', 'error', '-y'];
  if (isVideo) args.push('-stream_loop', '-1', '-i', image);
  else args.push('-loop', '1', '-framerate', String(fps), '-i', image);
  args.push('-i', audio);

  let vf;
  if (fit === 'contain') {
    vf = `scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2:color=0x0f172a,format=yuv420p`;
  } else {
    const zoom = index % 2 === 0
      ? `zoompan=z='min(zoom+0.00030,1.10)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${width}x${height}:fps=${fps}`
      : `zoompan=z='if(eq(on,1),1.10,max(zoom-0.00030,1.0))':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=${width}x${height}:fps=${fps}`;
    vf = `scale=${width}:${height}:force_original_aspect_ratio=increase,crop=${width}:${height},${zoom},format=yuv420p`;
  }
  const apad = seconds ? `apad=whole_dur=${seconds}` : 'apad=pad_dur=0.35';
  args.push('-filter_complex', `[0:v]${vf}[v];[1:a]${apad}[a]`);
  args.push('-map', '[v]', '-map', '[a]',
    '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '23', '-pix_fmt', 'yuv420p',
    '-r', String(fps), '-c:a', 'aac', '-b:a', '128k', '-ar', '24000', '-ac', '1');
  if (seconds) args.push('-t', String(seconds));
  else args.push('-shortest');
  args.push(out);
  await run(ffmpeg, args);
  return out;
}

async function concat(segments, out) {
  const ffmpeg = whichFfmpeg();
  const dir = path.dirname(segments[0]);
  const list = path.join(dir, 'concat.txt');
  await fsp.writeFile(list, segments.map(p => `file '${p.replace(/'/g, "'\\''")}'`).join('\n') + '\n');
  try {
    await run(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', '-movflags', '+faststart', out]);
  } catch (e) {
    console.log(`  stream-copy concat failed, re-encoding: ${e.message.split('\n')[0]}`);
    await run(ffmpeg, ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', list, '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', out]);
  }
  return out;
}

async function main() {
  loadEnv();
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { usage(); return; }
  if (args.listVoices) { await listVoices(args.language); return; }

  let spec;
  if (args.spec) {
    spec = JSON.parse(await fsp.readFile(args.spec, 'utf8'));
  } else if (args.prompt) {
    spec = {
      title: args.title || 'QCODE Video',
      language: args.language || 'en',
      scenes: [{ imagePrompt: args.prompt, narration: args.prompt, seconds: Number(args.seconds) || 6 }],
    };
  } else {
    usage();
    process.exitCode = 2;
    return;
  }

  const width = Number(spec.width) || DEFAULT_WIDTH;
  const height = Number(spec.height) || DEFAULT_HEIGHT;
  const fps = Number(spec.fps) || DEFAULT_FPS;
  const scenes = Array.isArray(spec.scenes) ? spec.scenes : [];
  if (!scenes.length) throw new Error('spec.scenes must contain at least one scene');

  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const work = path.resolve(args.work || path.join(process.cwd(), '.qcode-video', `${slugify(spec.title)}-${stamp}`));
  await fsp.mkdir(work, { recursive: true });
  const out = path.resolve(args.out || path.join(process.cwd(), 'qcode-videos', `${slugify(spec.title)}-${stamp}.mp4`));
  await fsp.mkdir(path.dirname(out), { recursive: true });
  const voice = await resolveVoice(spec, args.voice);
  const provider = String(args.imageProvider || spec.imageProvider || process.env.QCODE_IMAGE_PROVIDER || 'pollinations').toLowerCase();
  const flowProject = args.flowProject || spec.flowProject || process.env.QCODE_FLOW_PROJECT || null;
  const ttsProvider = String(args.ttsProvider || spec.ttsProvider || process.env.QCODE_TTS_PROVIDER || 'auto').toLowerCase();
  console.log(`QCODE Video Studio`);
  console.log(`  title: ${spec.title || '(untitled)'}`);
  console.log(`  language: ${spec.language || 'en'}  voice: ${voice}  tts: ${ttsProvider}`);
  console.log(`  images: ${provider}${provider === 'flow' && flowProject ? ` (${flowProject})` : ''}`);
  console.log(`  scenes: ${scenes.length}  size: ${width}x${height}@${fps}`);
  console.log(`  work: ${work}`);
  console.log(`  output: ${out}`);

  const segments = [];
  for (let i = 0; i < scenes.length; i++) {
    const scene = scenes[i];
    const n = String(i + 1).padStart(2, '0');
    console.log(`\nScene ${n}/${String(scenes.length).padStart(2, '0')}`);
    let image;
    if (scene.image) {
      image = path.resolve(scene.image);
      if (!fs.existsSync(image)) throw new Error(`scene ${n}: image not found: ${image}`);
      console.log(`  image: ${image}`);
    } else {
      const prompt = scene.imagePrompt || scene.prompt || spec.title || 'cinematic scene';
      const sceneProvider = String(scene.imageProvider || provider).toLowerCase();
      image = path.join(work, `scene-${n}.jpg`);
      let made = false;
      if (sceneProvider === 'flow') {
        try {
          await generateFlowImage({
            prompt,
            dest: image,
            project: scene.flowProject || flowProject,
            timeoutMs: Number(scene.flowTimeoutMs || spec.flowTimeoutMs) || 180000,
          });
          made = true;
        } catch (e) {
          console.log(`  flow image failed (${e.message.split('\n')[0]}); falling back`);
        }
      }
      if (!made) {
        try {
          await fetchImage(prompt, width, height, 1000 + i, image);
          made = true;
        } catch (e) {
          console.log(`  image generation failed (${e.message}); using gradient fallback`);
          await fallbackImage(image, width, height);
        }
      }
    }
    const narration = scene.narration || scene.text || '';
    let audio = null;
    if (narration.trim()) {
      console.log(`  voice: ${narration.slice(0, 70)}${narration.length > 70 ? '…' : ''}`);
      audio = await synthesizeText({
        text: narration,
        dir: path.join(work, `audio-${n}`),
        lang: String(scene.language || spec.language || 'en').toLowerCase().split('-')[0],
        provider: scene.ttsProvider || ttsProvider,
        voices: {
          gemini: args.geminiVoice || scene.geminiVoice || spec.geminiVoice || null,
          elevenlabs: args.elevenLabsVoice || scene.elevenLabsVoice || spec.elevenLabsVoice || null,
          edge: args.voice || scene.voice || spec.voice || voice,
        },
        prosody: {
          rate: String(spec.rate || scene.rate || '+0%'),
          pitch: String(spec.pitch || scene.pitch || '+0Hz'),
          volume: String(spec.volume || scene.volume || '+0%'),
        },
      });
    } else {
      throw new Error(`scene ${n}: narration is empty`);
    }
    const seg = path.join(work, `segment-${n}.mp4`);
    await makeSegment({
      image, audio, out: seg, width, height, fps,
      fit: scene.fit || spec.fit || 'cover',
      seconds: scene.seconds ? Number(scene.seconds) : null,
      index: i,
    });
    segments.push(seg);
    console.log(`  segment ok`);
  }

  console.log('\nJoining scenes...');
  await concat(segments, out);
  const stat = await fsp.stat(out);
  await fsp.writeFile(path.join(work, 'spec.json'), JSON.stringify(spec, null, 2));
  await fsp.copyFile(path.join(work, 'spec.json'), path.join(path.dirname(out), `${path.basename(out, '.mp4')}.json`));
  console.log(`\nDone: ${out}`);
  console.log(`Size: ${(stat.size / (1024 * 1024)).toFixed(2)} MiB`);
  if (!args.keepWork) {
    await fsp.rm(work, { recursive: true, force: true });
    console.log('Work files cleaned (use --keep-work to keep them).');
  } else {
    console.log(`Work files kept: ${work}`);
  }
}

main().catch(e => {
  console.error(`\nFAILED: ${e.stack || e.message}`);
  process.exit(1);
});
