import http from 'node:http';
import fs from 'node:fs';
import fsp from 'node:fs/promises';

const CDP_HTTP = process.env.QCODE_CDP || 'http://127.0.0.1:9222';
const FLOW_HOST = 'flow.google.com';

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function getJson(url) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, res => {
      let data = '';
      res.on('data', c => { data += c; });
      res.on('end', () => {
        try { resolve(JSON.parse(data)); } catch (e) { reject(new Error(`Bad CDP JSON: ${e.message}`)); }
      });
    });
    req.on('error', reject);
    req.setTimeout(5000, () => req.destroy(new Error('CDP HTTP timeout')));
  });
}

async function openFlowPage() {
  let targets;
  try { targets = await getJson(`${CDP_HTTP}/json`); }
  catch (e) { throw new Error(`DeepX CDP is not reachable at ${CDP_HTTP}. Run the host forward helper first.`); }
  const page = targets.find(t => t.type === 'page' && t.url.includes(FLOW_HOST));
  if (!page) throw new Error('Google Flow is not open in the QCODE Browser.');
  return page;
}

class Cdp {
  constructor(wsUrl) {
    this.ws = new WebSocket(wsUrl);
    this.id = 0;
    this.pending = new Map();
    this.ready = new Promise((resolve, reject) => {
      this.ws.onopen = resolve;
      this.ws.onerror = () => reject(new Error('CDP WebSocket failed'));
    });
    this.ws.onmessage = ev => {
      const msg = JSON.parse(ev.data);
      if (msg.id && this.pending.has(msg.id)) {
        const p = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error.message || 'CDP error'));
        else p.resolve(msg.result);
      }
    };
  }
  async send(method, params = {}) {
    await this.ready;
    return new Promise((resolve, reject) => {
      const id = ++this.id;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP ${method} timed out`));
      }, 30000);
      this.pending.set(id, {
        resolve: v => { clearTimeout(timer); resolve(v); },
        reject: e => { clearTimeout(timer); reject(e); },
      });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression) {
    const r = await this.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text || 'Page script failed');
    return r.result?.value;
  }
  close() { try { this.ws.close(); } catch {} }
}

const IMAGE_QUERY = `[...document.querySelectorAll('img')]
  .filter(i => /flow-content\\.google\\/image\\//.test(i.src))
  .map(i => ({ src: i.src, w: i.naturalWidth, h: i.naturalHeight }))`;

async function projectUrl(cdp) {
  const url = await cdp.eval('location.href');
  return /\/project\/[0-9a-f-]{16,}/i.test(url) ? url : null;
}

async function openOrCreateProject(cdp, requested) {
  if (requested) {
    const current = await cdp.eval('location.href');
    if (current !== requested) {
      await cdp.send('Page.navigate', { url: requested });
      await sleep(7000);
    }
  }
  let url = await projectUrl(cdp);
  if (url) return url;
  await cdp.send('Page.navigate', { url: `https://${FLOW_HOST}` });
  await sleep(6000);
  await cdp.eval(`(() => {
    const b = [...document.querySelectorAll('button')].find(x => (x.innerText || '').includes('New project'));
    if (!b) return false;
    b.click();
    return true;
  })()`);
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    url = await projectUrl(cdp);
    if (url) return url;
  }
  throw new Error('Flow project did not open.');
}

async function setPrompt(cdp, prompt) {
  const ok = await cdp.eval(`(() => {
    const e = document.querySelector('.ProseMirror');
    if (!e) return false;
    e.focus();
    document.execCommand('selectAll');
    document.execCommand('delete');
    return true;
  })()`);
  if (!ok) throw new Error('Flow prompt editor not found (is the project loaded?).');
  await cdp.send('Input.insertText', { text: prompt });
  await sleep(600);
  const text = await cdp.eval(`document.querySelector('.ProseMirror')?.innerText || ''`);
  if (!text.includes(prompt.slice(0, 24))) throw new Error('Flow prompt was not accepted.');
}

async function clickGenerate(cdp) {
  const found = await cdp.eval(`(() => {
    const b = [...document.querySelectorAll('button')].find(x => x.getAttribute('aria-label') === 'Start generation');
    if (!b) return false;
    b.scrollIntoView({ block: 'center', inline: 'center' });
    return true;
  })()`);
  if (!found) throw new Error('Flow Start generation button not found.');
  await sleep(700);
  const info = JSON.parse(await cdp.eval(`JSON.stringify((() => {
    const b = [...document.querySelectorAll('button')].find(x => x.getAttribute('aria-label') === 'Start generation');
    if (!b) return null;
    return {
      rect: b.getBoundingClientRect().toJSON(),
      vv: { h: visualViewport.height, oy: visualViewport.offsetTop }
    };
  })())`));
  if (!info) throw new Error('Flow Start generation button disappeared.');
  const x = info.rect.x + info.rect.width / 2;
  const y = info.rect.y + info.rect.height / 2 - info.vv.oy;
  await cdp.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
  await cdp.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
}

async function fetchImage(url, dest) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Image download HTTP ${res.status}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 5000) throw new Error('Image download too small');
  await fsp.writeFile(dest, buf);
  return dest;
}

export async function generateFlowImage({ prompt, dest, project, timeoutMs = 180000, aspect = null }) {
  const page = await openFlowPage();
  const cdp = new Cdp(page.webSocketDebuggerUrl);
  try {
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await openOrCreateProject(cdp, project);
    const before = new Set(JSON.parse(await cdp.eval(`JSON.stringify(${IMAGE_QUERY})`)).map(i => i.src));
    await setPrompt(cdp, prompt);
    await clickGenerate(cdp);

    const deadline = Date.now() + timeoutMs;
    let picked = null;
    while (Date.now() < deadline) {
      await sleep(2500);
      const images = JSON.parse(await cdp.eval(`JSON.stringify(${IMAGE_QUERY})`));
      const fresh = images.filter(i => !before.has(i.src) && i.w > 0 && i.h > 0);
      if (fresh.length) {
        picked = fresh[0];
        break;
      }
      const body = await cdp.eval('document.body.innerText.slice(0, 1200)');
      if (/failed|error|try again|Something went wrong/i.test(body)) {
        throw new Error(`Flow reported an error: ${body.slice(0, 160)}`);
      }
    }
    if (!picked) throw new Error('Flow image generation timed out.');
    await fetchImage(picked.src, dest);
    const st = await fsp.stat(dest);
    console.log(`  flow image ok (${Math.round(st.size / 1024)} KiB, ${picked.w}x${picked.h})`);
    return dest;
  } finally {
    cdp.close();
  }
}
