import http from 'node:http';
const CDP_HTTP = process.env.QCODE_CDP || 'http://127.0.0.1:9222';
function getJson(url){return new Promise((res,rej)=>{const q=http.get(url,r=>{let d='';r.on('data',c=>d+=c);r.on('end',()=>{try{res(JSON.parse(d));}catch(e){rej(e);}});});q.on('error',rej);q.setTimeout(5000,()=>q.destroy(new Error('timeout')));});}
class Cdp{constructor(u){this.ws=new WebSocket(u);this.id=0;this.p=new Map();this.ready=new Promise((r,j)=>{this.ws.onopen=r;this.ws.onerror=()=>j(new Error('ws'));});this.ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.id&&this.p.has(m.id)){const x=this.p.get(m.id);this.p.delete(m.id);m.error?x.j(new Error(m.error.message)):x.r(m.result);}};}async send(m,a={}){await this.ready;return new Promise((r,j)=>{const id=++this.id;const t=setTimeout(()=>{this.p.delete(id);j(new Error(m+' timeout'));},30000);this.p.set(id,{r:v=>{clearTimeout(t);r(v);},j:e=>{clearTimeout(t);j(e);}});this.ws.send(JSON.stringify({id,method:m,params:a}));});}async eval(e){const r=await this.send('Runtime.evaluate',{expression:e,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw new Error(r.exceptionDetails.text);return r.result?.value;}close(){try{this.ws.close();}catch{}}}
const targets=await getJson(`${CDP_HTTP}/json`);const page=targets.find(t=>t.type==='page');const cdp=new Cdp(page.webSocketDebuggerUrl);
try{
 await cdp.send('Runtime.enable');
 console.log(await cdp.eval(`(() => {
   const label=[...document.querySelectorAll('.action-card-label')].find(e=>(e.innerText||'').trim()==='Create new dialog');
   if(!label) return 'no label';
   const out=[]; let el=label;
   for(let i=0;i<6&&el;i++){ out.push({i,tag:el.tagName,role:el.getAttribute('role'),tab:el.getAttribute('tabindex'),cls:(el.className||'').toString().slice(0,100),aria:el.getAttribute('aria-label'),html:el.outerHTML.slice(0,500)}); el=el.parentElement; }
   return JSON.stringify(out,null,1);
 })()`));
}finally{cdp.close();}
